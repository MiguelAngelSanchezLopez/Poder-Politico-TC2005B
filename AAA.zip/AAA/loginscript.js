document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");
    // Otros elementos y funciones necesarios

    // Evento de envío del formulario de inicio de sesión
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const username = loginForm.querySelector('input[type="text"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;
        // Verifica el usuario y la contraseña, y realiza cualquier otro procesamiento necesario
        // Si el inicio de sesión es exitoso:
        // Guarda el nombre de usuario en el sessionStorage
        sessionStorage.setItem("username", username);
        // Redirige al usuario de vuelta a program.html
        window.location.href = "program.html";
        // Puedes ocultar el formulario de inicio de sesión o realizar otras acciones aquí si lo deseas
    });

    // Otros eventos y funciones necesarios
});

document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");
    const registerLink = document.getElementById("registerLink");
    const loginLink = document.getElementById("loginLink");

    // Función para guardar los datos en el almacenamiento de sesión
    function saveUserData(username, password) {
        sessionStorage.setItem("username", username);
        sessionStorage.setItem("password", password);
    }

    // Función para cargar los datos del almacenamiento de sesión al formulario de inicio de sesión
    function loadUserData() {
        const savedUsername = sessionStorage.getItem("username");
        const savedPassword = sessionStorage.getItem("password");
        if (savedUsername && savedPassword) {
            loginForm.querySelector('input[type="text"]').value = savedUsername;
            loginForm.querySelector('input[type="password"]').value = savedPassword;
        }
    }

    // Cargar datos del almacenamiento de sesión al formulario de inicio de sesión si están disponibles
    loadUserData();

    registerLink.addEventListener("click", function(e) {
        e.preventDefault();
        loginForm.classList.add("hidden");
        registerForm.classList.remove("hidden");
    });

    loginLink.addEventListener("click", function(e) {
        e.preventDefault();
        registerForm.classList.add("hidden");
        loginForm.classList.remove("hidden");
    });

    // Evento de envío del formulario de registro
    registerForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const username = registerForm.querySelector('input[type="text"]').value;
        const password = registerForm.querySelector('input[type="password"]').value;
        saveUserData(username, password);
        alert("¡Usuario registrado correctamente!");
        registerForm.reset();
        registerForm.classList.add("hidden");
        loginForm.classList.remove("hidden");
    });
});


// Para añadir el logout, usuario y quitar el login, y al revés.
document.addEventListener("DOMContentLoaded", function() {
    const username = sessionStorage.getItem("username");
    if (username) {
        const usernameDisplay = document.getElementById("usernameDisplay");
        usernameDisplay.textContent = "Usuario: " + username;
        const logoutButton = document.getElementById("logoutButton");
        logoutButton.style.display = "block"; // Muestra el botón de logout

        // Oculta el botón de login
        const loginButton = document.getElementById("loginButton");
        loginButton.style.display = "none";
    }
});

// Para el botón de empezar el juego

document.addEventListener("DOMContentLoaded", function() {
    const playNowLink = document.getElementById("playNowLink");

    // Comprueba si hay un nombre de usuario en el sessionStorage
    const username = sessionStorage.getItem("username");
    if (username) {
        // Si hay un nombre de usuario, actualiza el href del enlace para que apunte al enlace directo
        playNowLink.href = "https://blog.hubspot.com/";
    } else {
        // Si no hay un nombre de usuario, actualiza el href del enlace para que apunte a login.html
        playNowLink.href = "login.html";
    }
});




/*document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");
    // Otros elementos y funciones necesarios

    // Evento de envío del formulario de inicio de sesión
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const username = loginForm.querySelector('input[type="text"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;
        // Verifica el usuario y la contraseña, y realiza cualquier otro procesamiento necesario
        // Si el inicio de sesión es exitoso:
        // Guarda el nombre de usuario en el localStorage
        localStorage.setItem("username", username);
        // Redirige al usuario de vuelta a program.html
        window.location.href = "program.html";
        // Puedes ocultar el formulario de inicio de sesión o realizar otras acciones aquí si lo deseas
    });

    // Otros eventos y funciones necesarios
});

document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");
    const registerLink = document.getElementById("registerLink");
    const loginLink = document.getElementById("loginLink");

    // Función para guardar los datos en el almacenamiento local
    function saveUserData(username, password) {
        localStorage.setItem("username", username);
        localStorage.setItem("password", password);
    }

    // Función para cargar los datos del almacenamiento local al formulario de inicio de sesión
    function loadUserData() {
        const savedUsername = localStorage.getItem("username");
        const savedPassword = localStorage.getItem("password");
        if (savedUsername && savedPassword) {
            loginForm.querySelector('input[type="text"]').value = savedUsername;
            loginForm.querySelector('input[type="password"]').value = savedPassword;
        }
    }

    // Cargar datos del almacenamiento local al formulario de inicio de sesión si están disponibles
    loadUserData();

    registerLink.addEventListener("click", function(e) {
        e.preventDefault();
        loginForm.classList.add("hidden");
        registerForm.classList.remove("hidden");
    });

    loginLink.addEventListener("click", function(e) {
        e.preventDefault();
        registerForm.classList.add("hidden");
        loginForm.classList.remove("hidden");
    });

    // Evento de envío del formulario de registro
    registerForm.addEventListener("submit", function(e) {
        e.preventDefault();
        const username = registerForm.querySelector('input[type="text"]').value;
        const password = registerForm.querySelector('input[type="password"]').value;
        saveUserData(username, password);
        alert("¡Usuario registrado correctamente!");
        registerForm.reset();
        registerForm.classList.add("hidden");
        loginForm.classList.remove("hidden");
    });
});


// Para añadir el logout, usuario y quitar el login, y al reves.
document.addEventListener("DOMContentLoaded", function() {
    const username = localStorage.getItem("username");
    if (username) {
        const usernameDisplay = document.getElementById("usernameDisplay");
        usernameDisplay.textContent = "Usuario: " + username;
        const logoutButton = document.getElementById("logoutButton");
        logoutButton.style.display = "block"; // Muestra el botón de logout

        // Oculta el botón de login
        const loginButton = document.getElementById("loginButton");
        loginButton.style.display = "none";
    }
});

// Para el boton de empezar el juego

document.addEventListener("DOMContentLoaded", function() {
    const playNowLink = document.getElementById("playNowLink");

    // Comprueba si hay un nombre de usuario en el sessionStorage
    const username = sessionStorage.getItem("username");
    if (username) {
        // Si hay un nombre de usuario, actualiza el href del enlace para que apunte al enlace directo
        playNowLink.href = "https://blog.hubspot.com/";
    } else {
        // Si no hay un nombre de usuario, actualiza el href del enlace para que apunte a login.html
        playNowLink.href = "login.html";
    }
});
*/